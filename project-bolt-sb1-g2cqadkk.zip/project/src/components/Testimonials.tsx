import { Star, Quote } from 'lucide-react';

export function Testimonials() {
  const testimonials = [
    {
      name: 'Ana C.',
      text: 'Me senti menos inchada já na primeira semana.',
      rating: 5
    },
    {
      name: 'Marcos L.',
      text: 'Simples, fácil e realmente funciona.',
      rating: 5
    },
    {
      name: 'Juliana R.',
      text: 'Vale muito mais do que custa.',
      rating: 5
    }
  ];

  return (
    <section id="avaliacoes" className="py-16 sm:py-24 px-4 bg-gradient-to-b from-emerald-50/30 to-white">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center text-gray-900 mb-4">
          O que as pessoas estão dizendo
        </h2>
        <div className="w-20 h-1 bg-emerald-500 mx-auto mb-12 sm:mb-16"></div>

        <div className="grid md:grid-cols-3 gap-6 sm:gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 hover:border-emerald-200 relative group"
            >
              <Quote className="w-10 h-10 text-emerald-200 mb-4 group-hover:text-emerald-300 transition-colors" />

              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-emerald-500 text-emerald-500" />
                ))}
              </div>

              <p className="text-gray-700 text-lg leading-relaxed mb-6 italic">
                "{testimonial.text}"
              </p>

              <p className="font-semibold text-gray-900">
                {testimonial.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
