export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-8 px-4">
      <div className="max-w-6xl mx-auto text-center">
        <p className="text-gray-400">
          © 2026 DESINCHA FAST – Todos os direitos reservados
        </p>
      </div>
    </footer>
  );
}
