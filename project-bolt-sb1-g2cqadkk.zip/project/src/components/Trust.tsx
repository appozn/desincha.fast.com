import { Shield, Zap, Package } from 'lucide-react';

export function Trust() {
  const features = [
    {
      icon: Shield,
      title: 'Pagamento 100% seguro via Pix',
    },
    {
      icon: Zap,
      title: 'Entrega imediata no e-mail',
    },
    {
      icon: Package,
      title: 'Produto digital',
    }
  ];

  return (
    <section className="py-12 sm:py-16 px-4 bg-emerald-50/50">
      <div className="max-w-5xl mx-auto">
        <div className="grid md:grid-cols-3 gap-6 sm:gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="flex flex-col items-center text-center group"
            >
              <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-emerald-500/30">
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <p className="text-gray-900 font-semibold text-lg">
                {feature.title}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
